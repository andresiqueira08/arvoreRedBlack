package arvoreredblack;

import java.util.LinkedList;
import java.util.Queue;

class RbTree {
    private Node root;

    public void inserir(int valor) {
        Node novo = new Node(valor);

        // Caso 1: árvore vazia: novo nó vira raiz preta
        if (root == null) {
            root = novo;
            root.setRed(false);
            return;
        }

        // Busca a posição correta para inserir o novo nó
        Node atual = root;
        Node pai = null;

        while (atual != null) {
            pai = atual;
            if (valor < atual.getInfo()) {
                atual = atual.getLeft();
            } else if (valor > atual.getInfo()) {
                atual = atual.getRight();
            } else {
                // Valor já existe: nada a fazer
                return;
            }
        }

        // Define o pai
        novo.setParent(pai);

        // Insere o nó
        if (valor < pai.getInfo()) {
            pai.setLeft(novo);
        } else {
            pai.setRight(novo);
        }

        // Corrige propriedades da Red-Black Tree
        corrigirInsercao(novo);
    }

    private void corrigirInsercao(Node novo) {
        while (novo != root && novo.getParent().isRed()) {
            Node pai = novo.getParent();
            Node avo = pai.getParent();

            if (avo == null) {
                break;
            }

            // Pai está à esquerda do avô
            if (pai == avo.getLeft()) {
                Node tio = avo.getRight();

                // Caso 1: tio vermelho → recoloração
                if (tio != null && tio.isRed()) {
                    pai.setRed(false);
                    tio.setRed(false);
                    avo.setRed(true);
                    novo = avo;
                } else {
                    // Caso 2: nó é filho direito → rotação esquerda
                    if (novo == pai.getRight()) {
                        novo = pai;
                        rotacaoEsquerda(novo);
                        pai = novo.getParent();
                    }
                    // Caso 3: nó é filho esquerdo → rotação direita
                    pai.setRed(false);
                    avo.setRed(true);
                    rotacaoDireita(avo);
                }
            } 
            // Pai está à direita do avô
            else {
                Node tio = avo.getLeft();

                if (tio != null && tio.isRed()) {
                    pai.setRed(false);
                    tio.setRed(false);
                    avo.setRed(true);
                    novo = avo;
                } else {
                    if (novo == pai.getLeft()) {
                        novo = pai;
                        rotacaoDireita(novo);
                        pai = novo.getParent();
                    }
                    pai.setRed(false);
                    avo.setRed(true);
                    rotacaoEsquerda(avo);
                }
            }
        }

        root.setRed(false); // raiz sempre preta
    }

    private void rotacaoEsquerda(Node x) {
        Node y = x.getRight();
        x.setRight(y.getLeft());
        if (y.getLeft() != null) y.getLeft().setParent(x);

        y.setParent(x.getParent());
        if (x.getParent() == null) {
            root = y;
        } else if (x == x.getParent().getLeft()) {
            x.getParent().setLeft(y);
        } else {
            x.getParent().setRight(y);
        }

        y.setLeft(x);
        x.setParent(y);
    }

    private void rotacaoDireita(Node y) {
        Node x = y.getLeft();
        y.setLeft(x.getRight());
        if (x.getRight() != null) x.getRight().setParent(y);

        x.setParent(y.getParent());
        if (y.getParent() == null) {
            root = x;
        } else if (y == y.getParent().getLeft()) {
            y.getParent().setLeft(x);
        } else {
            y.getParent().setRight(x);
        }

        x.setRight(y);
        y.setParent(x);
    }

    // Passeios:

    public void emOrdem() {
        percorrerEmOrdem(root);
        System.out.println();
    }

    private void percorrerEmOrdem(Node r) {
        if (r != null) {
            percorrerEmOrdem(r.getLeft());
            System.out.print(r.getInfo() + (r.isRed() ? "(RED) " : "(BLACK) "));
            percorrerEmOrdem(r.getRight());
        }
    }

    public void porNivel() {
        if (root == null) return;
        Queue<Node> fila = new LinkedList<>();
        fila.add(root);
        while (!fila.isEmpty()) {
            Node atual = fila.poll();
            System.out.print(atual.getInfo() + (atual.isRed() ? "(RED) " : "(BLACK) "));
            if (atual.getLeft() != null){ 
                fila.add(atual.getLeft());
            }
            if (atual.getRight() != null){ 
                fila.add(atual.getRight());
            }
        }
        System.out.println();
    }
}